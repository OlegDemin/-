﻿using System;

namespace ClassLibrary1
{
    class Int
    {
        class Input
        {
            public static void InputArray(ref int[,] a)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);
                string[] st;
                for (byte i = 0; i < n; i++)
                {
                    st = Console.ReadLine().Split();
                    for (byte j = 0; j < m; j++)
                        a[i, j] = Convert.ToInt32(st[j]);
                }
                Console.Write("\n");
            }

            public static void InputArray(ref int[] a)
            {
                int n = a.Length;
                for (byte i = 0; i < n; i++)
                    a[i] = Convert.ToInt32(Console.ReadLine());
                Console.Write("\n");
            }
        }

        class Random
        {
            public static void RandomArray(ref int[,] a, int p, int q)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);
                Random rnd = new Random();

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < m; j++)
                        a[i, j] = rnd.Next(p, q + 1);
            }

            public static void RandomArray(ref int[] a, int p, int q)
            {
                int n = a.Length;
                Random rnd = new Random();

                for (byte i = 0; i < n; i++)
                    a[i] = rnd.Next(p, q + 1);
            }
        }

        class Print
        {
            public static void PrintArray(int[,] a)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);

                for (byte i = 0; i < n; i++)
                {
                    for (byte j = 0; j < m; j++)
                        Console.Write($"{a[i, j]} ");
                    Console.Write("\n");
                }
                Console.Write("\n");
            }

            public static void PrintArray(int[] a)
            {
                int n = a.GetLength(0);
                for (byte i = 0; i < n; i++)
                    Console.Write($"{a[i]} ");
                Console.Write("\n");
            }
        }
    }

    class Double
    {
        class Input
        {
            public static void InputArray(ref double[,] a)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);
                string[] st;
                for (byte i = 0; i < n; i++)
                {
                    st = Console.ReadLine().Split();
                    for (byte j = 0; j < m; j++)
                        a[i, j] = Convert.ToDouble(st[j]);
                }
                Console.Write("\n");
            }

            public static void InputArray(ref double[] a)
            {
                int n = a.Length;
                for (byte i = 0; i < n; i++)
                    a[i] = Convert.ToDouble(Console.ReadLine());
                Console.Write("\n");
            }
        }

        class Random
        {
            public static void RandomArray(ref double[,] a, int p, int q)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);
                Random rnd = new Random();

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < m; j++)
                        a[i, j] = rnd.Next(p, q + 1) + Math.Round(rnd.NextDouble(), 2);
            }

            public static void RandomArray(ref double[] a, int p, int q)
            {
                int n = a.Length;
                Random rnd = new Random();

                for (byte i = 0; i < n; i++)
                    a[i] = rnd.Next(p, q + 1) + Math.Round(rnd.NextDouble(), 2);
            }
        }

        class Print
        {
            public static void PrintArray(double[,] a)
            {
                int n = a.GetLength(0);
                int m = a.GetLength(1);

                for (byte i = 0; i < n; i++)
                {
                    for (byte j = 0; j < m; j++)
                        Console.Write($"{a[i, j]} ");
                    Console.Write("\n");
                }
                Console.Write("\n");
            }

            public static void PrintArray(double[] a)
            {
                int n = a.GetLength(0);
                for (byte i = 0; i < n; i++)
                    Console.Write($"{a[i]} ");
                Console.Write("\n");
            }
        }
    }
}
