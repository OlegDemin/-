﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Play
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("В данной игре вам дано всего два действия");
            Console.Write("1.) Открыть клетку: \"");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("клетка");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\"");

            Console.Write("2.) Поставить флаг: \"");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("флаг");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\"\n");

            Input.N_M_K(out byte n, out byte m, out byte numBombs);
            byte[,] a = new byte[n, m];
            Print.Defoul(a, numBombs);

            Console.WriteLine("Откройте первую клетку");
            Input.I_J.Cell(a, out byte st_i, out byte st_j);
            Open.Locate_Bombs(ref a, numBombs, st_i, st_j);
            Print.Defoul(a, numBombs);

            while (true)
            {
                if (Input.Cell_or_Flag())
                {
                    Input.I_J.Cell(a, out byte i, out byte j);
                    Open.Cell(ref a, i, j);
                    if (a[i, j] == 9)
                    {
                        Open.All(ref a);
                        Print.End(a);
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("ВЫ ПРОИГРАЛИ!");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.ReadKey();
                        return;
                    }
                    else
                        Print.Defoul(a, numBombs);
                }
                else if (numBombs != 0)
                {
                    Input.I_J.Flag(a, out byte i, out byte j);
                    if (a[i, j] == 10 || a[i, j] == 19)
                    {
                        a[i, j] -= 10;
                        numBombs++;
                    }
                    else
                    {
                        a[i, j] += 10;
                        numBombs--;
                    }
                    Print.Defoul(a, numBombs);
                }
                else
                {
                    Input.I_J.RemFlag(a, out byte i, out byte j);
                    a[i, j] -= 10;
                    numBombs++;
                    Print.Defoul(a, numBombs);
                }

                bool go = false;
                foreach (int ij in a)
                    if (ij == 9 || ij == 0)
                    {
                        go = true;
                        break;
                    }
                if (go)
                    continue;
                else
                {
                    Open.All(ref a);
                    Print.End(a);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("ВЫ ВЫЙГРАЛИ!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.ReadKey();
                    return;
                }
            }
        }


        class Input
        {
            public static void N_M_K(out byte n, out byte m, out byte k)
            {
                Console.Write("Длинна столбца:  ");
                string st_n = Console.ReadLine();
                Console.Write("Длинна строки:   ");
                string st_m = Console.ReadLine();
                Console.Write("Количество бомб: ");
                string st_k = Console.ReadLine();
                Console.Write("\n");

                if (!byte.TryParse(st_n, out n) || !byte.TryParse(st_m, out m) || !byte.TryParse(st_k, out k))
                    N_M_K(out n, out m, out k);
                if (n * m < k + 8 || n == 0 || m == 0 || k == 0 || n > 80 || m > 80)
                    N_M_K(out n, out m, out k);
            }

            public static bool Cell_or_Flag()
            {
                Console.Write("Действие: ");
                string st = Console.ReadLine();
                if (st == "клетка")
                    return true;
                else if (st == "флаг")
                    return false;
                else
                    return Cell_or_Flag();
            }

            public class I_J
            {
                public static void Cell(byte[,] a, out byte i, out byte j)
                {
                    byte n = (byte)a.GetLength(0);
                    byte m = (byte)a.GetLength(1);

                    Console.Write("i: ");
                    string st_i = Console.ReadLine();
                    Console.Write("j: ");
                    string st_j = Console.ReadLine();
                    Console.Write("\n");

                    if (!byte.TryParse(st_i, out i) || !byte.TryParse(st_j, out j) || i >= n || j >= m)
                        Cell(a, out i, out j);
                    if (a[i, j] != 0 && a[i, j] != 9)
                        Cell(a, out i, out j);
                }

                public static void Flag(byte[,] a, out byte i, out byte j)
                {
                    byte n = (byte)a.GetLength(0);
                    byte m = (byte)a.GetLength(1);

                    Console.Write("i: ");
                    string st_i = Console.ReadLine();
                    Console.Write("j: ");
                    string st_j = Console.ReadLine();
                    Console.Write("\n");

                    if (!byte.TryParse(st_i, out i) || !byte.TryParse(st_j, out j) || i >= n || j >= m)
                        Flag(a, out i, out j);
                    if ((a[i, j] % 10 != 0 && a[i, j] % 10 != 9) || a[i, j] == 100)
                        Flag(a, out i, out j);
                }

                public static void RemFlag(byte[,] a, out byte i, out byte j)
                {
                    byte n = (byte)a.GetLength(0);
                    byte m = (byte)a.GetLength(1);

                    Console.Write("i: ");
                    string st_i = Console.ReadLine();
                    Console.Write("j: ");
                    string st_j = Console.ReadLine();
                    Console.Write("\n");

                    if (!byte.TryParse(st_i, out i) || !byte.TryParse(st_j, out j) || i >= n || j >= m)
                        RemFlag(a, out i, out j);
                    if (a[i, j] < 10 || a[i, j] > 19)
                        RemFlag(a, out i, out j);
                }
            }
        }


        class Open
        {
            public static void Cell(ref byte[,] a, int i, int j)
            {
                byte n = (byte)a.GetLength(0);
                byte m = (byte)a.GetLength(1);
                bool TrFl(int tf_i, int tf_j, byte tf_n, byte tf_m) => tf_i >= 0 && tf_i < tf_n && tf_j >= 0 && tf_j < tf_m;

                if (!TrFl(i, j, n, m) || a[i, j] != 0) return;

                if (TrFl(i - 1, j - 1, n, m) && a[i - 1, j - 1] % 10 == 9) a[i, j]++;
                if (TrFl(i - 1, j, n, m) && a[i - 1, j] % 10 == 9) a[i, j]++;
                if (TrFl(i - 1, j + 1, n, m) && a[i - 1, j + 1] % 10 == 9) a[i, j]++;

                if (TrFl(i, j - 1, n, m) && a[i, j - 1] % 10 == 9) a[i, j]++;
                if (TrFl(i, j + 1, n, m) && a[i, j + 1] % 10 == 9) a[i, j]++;

                if (TrFl(i + 1, j - 1, n, m) && a[i + 1, j - 1] % 10 == 9) a[i, j]++;
                if (TrFl(i + 1, j, n, m) && a[i + 1, j] % 10 == 9) a[i, j]++;
                if (TrFl(i + 1, j + 1, n, m) && a[i + 1, j + 1] % 10 == 9) a[i, j]++;

                if (a[i, j] == 0)
                {
                    a[i, j] = 100;

                    Cell(ref a, i - 1, j - 1);
                    Cell(ref a, i - 1, j);
                    Cell(ref a, i - 1, j + 1);

                    Cell(ref a, i, j - 1);
                    Cell(ref a, i, j + 1);

                    Cell(ref a, i + 1, j - 1);
                    Cell(ref a, i + 1, j);
                    Cell(ref a, i + 1, j + 1);
                }
            }

            public static void All(ref byte[,] a)
            {
                byte n = (byte)a.GetLength(0);
                byte m = (byte)a.GetLength(1);

                for (byte i = 0; i < n; i++)
                    for (byte j = 0; j < m; j++)
                        if (a[i, j] == 0)
                            Cell(ref a, i, j);
            }

            public static void Locate_Bombs(ref byte[,] a, byte k, byte start_i, byte start_j)
            {
                byte n = (byte)a.GetLength(0);
                byte m = (byte)a.GetLength(1);

                Random rnd = new Random();
                for (uint i = 0; i < k;)
                {
                    byte ri = (byte)rnd.Next(0, n);
                    byte rj = (byte)rnd.Next(0, m);
                    if (a[ri, rj] != 9 && (ri < start_i - 1 || ri > start_i + 1 || rj < start_j - 1 || rj > start_j + 1))
                    {
                        a[ri, rj] = 9;
                        i++;
                    }
                }
                Cell(ref a, start_i, start_j);
            }
        }


        class Print
        {
            public static void Defoul(byte[,] a, byte k)
            {
                byte n = (byte)a.GetLength(0);
                byte m = (byte)a.GetLength(1);

                Console.ForegroundColor = ConsoleColor.Blue;
                if (m > 10)
                {
                    Console.Write("".PadLeft(n.ToString().Length + 1));
                    for (byte j = 0; j < m; j++)
                        if (j / 10 != 0)
                            Console.Write($"{j / 10} ");
                        else
                            Console.Write("  ");
                    Console.Write("\n");
                }
                Console.Write("".PadLeft(n.ToString().Length + 1));
                for (byte j = 0; j < m; j++)
                    Console.Write($"{j % 10} ");
                Console.Write("\n");
                Console.ResetColor();

                for (byte i = 0; i < n; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write($"{i} ".PadLeft(n.ToString().Length + 1));
                    Console.ResetColor();
                    for (byte j = 0; j < m; j++)
                    {
                        if (a[i, j] == 100)
                            Console.Write("0 ");
                        else if (a[i, j] == 10 || a[i, j] == 19)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.Write("# ");
                            Console.ResetColor();
                        }
                        else if (a[i, j] == 0 || a[i, j] == 9)
                            Console.Write("* ");
                        else
                            Console.Write($"{a[i, j]} ");
                    }
                    Console.Write("\n");
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Осталось бомб: ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(k);
                Console.ForegroundColor = ConsoleColor.White;

                Console.Write("\n");
            }

            public static void End(byte[,] a)
            {
                byte n = (byte)a.GetLength(0);
                byte m = (byte)a.GetLength(1);

                Console.ForegroundColor = ConsoleColor.Blue;
                if (m > 10)
                {
                    Console.Write("".PadLeft(n.ToString().Length + 1));
                    for (byte j = 0; j < m; j++)
                        if (j / 10 != 0)
                            Console.Write($"{j / 10} ");
                        else
                            Console.Write("  ");
                    Console.Write("\n");
                }
                Console.Write("".PadLeft(n.ToString().Length + 1));
                for (byte j = 0; j < m; j++)
                    Console.Write($"{j % 10} ");
                Console.Write("\n");
                Console.ResetColor();

                for (byte i = 0; i < n; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write($"{i} ".PadLeft(n.ToString().Length + 1));
                    Console.ResetColor();
                    for (byte j = 0; j < m; j++)
                    {
                        if (a[i, j] == 100)
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write("0 ");
                        }
                        else if (a[i, j] == 19)
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("# ");
                            Console.ResetColor();
                        }
                        else if (a[i, j] >= 10 && a[i, j] <= 18)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.Write("# ");
                        }
                        else if (a[i, j] == 0 || a[i, j] == 9)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("* ");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{a[i, j]} ");
                        }
                    }
                    Console.Write("\n");
                }
                Console.Write("\n");
            }
        }
    }
}
