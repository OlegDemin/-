﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17_7
{
    class Program
    {
        static void Main(string[] args)
        {
            byte n = Convert.ToByte(Console.ReadLine());
            int[,] a = new int[n, n];
            Console.Write("\n");

            for (byte i = 0; i < n; i++)
                for (byte j = 0; j < n; j++)
                    if ((i + j) % 2 == 0)
                        a[i, j] = 1;
            Print(a);

            a = new int[n, n];
            Random rnd = new Random();
            for (byte i = 0; i < 10;)
            {
                byte ri = (byte)rnd.Next(0, n);
                byte rj = (byte)rnd.Next(0, n);
                if (a[ri, rj] != 9)
                {
                    a[ri, rj] = 9;
                    i++;
                }
            }
            Print(a);

            for (byte i = 0; i < n; i++)
                for (byte j = 0; j < n; j++)
                {
                    if (a[i, j] != 9)
                    {
                        if (i == 0)
                        {
                            if (j == 0)
                            {
                                if (a[i, j + 1] == 9) a[i, j]++;
                                if (a[i + 1, j] == 9) a[i, j]++;
                                if (a[i + 1, j + 1] == 9) a[i, j]++;
                            }
                            else if (j == n - 1)
                            {
                                if (a[i, j - 1] == 9) a[i, j]++;
                                if (a[i + 1, j - 1] == 9) a[i, j]++;
                                if (a[i + 1, j] == 9) a[i, j]++;
                            }
                            else
                            {
                                if (a[i, j - 1] == 9) a[i, j]++;
                                if (a[i, j + 1] == 9) a[i, j]++;

                                if (a[i + 1, j - 1] == 9) a[i, j]++;
                                if (a[i + 1, j] == 9) a[i, j]++;
                                if (a[i + 1, j + 1] == 9) a[i, j]++;
                            }
                        }
                        else if (i == n - 1)
                        {
                            if (j == 0)
                            {
                                if (a[i - 1, j] == 9) a[i, j]++;
                                if (a[i - 1, j + 1] == 9) a[i, j]++;
                                if (a[i, j + 1] == 9) a[i, j]++;
                            }
                            else if (j == n - 1)
                            {
                                if (a[i - 1, j - 1] == 9) a[i, j]++;
                                if (a[i - 1, j] == 9) a[i, j]++;
                                if (a[i, j - 1] == 9) a[i, j]++;
                            }
                            else
                            {
                                if (a[i - 1, j - 1] == 9) a[i, j]++;
                                if (a[i - 1, j] == 9) a[i, j]++;
                                if (a[i - 1, j + 1] == 9) a[i, j]++;

                                if (a[i, j - 1] == 9) a[i, j]++;
                                if (a[i, j + 1] == 9) a[i, j]++;
                            }
                        }
                        else if (j == 0)
                        {
                            if (a[i - 1, j] == 9) a[i, j]++;
                            if (a[i - 1, j + 1] == 9) a[i, j]++;

                            if (a[i, j + 1] == 9) a[i, j]++;

                            if (a[i + 1, j] == 9) a[i, j]++;
                            if (a[i + 1, j + 1] == 9) a[i, j]++;
                        }
                        else if (j == n - 1)
                        {
                            if (a[i - 1, j - 1] == 9) a[i, j]++;
                            if (a[i - 1, j] == 9) a[i, j]++;

                            if (a[i, j - 1] == 9) a[i, j]++;

                            if (a[i + 1, j - 1] == 9) a[i, j]++;
                            if (a[i + 1, j] == 9) a[i, j]++;
                        }
                        else
                        {
                            if (a[i - 1, j - 1] == 9) a[i, j]++;
                            if (a[i - 1, j] == 9) a[i, j]++;
                            if (a[i - 1, j + 1] == 9) a[i, j]++;

                            if (a[i, j - 1] == 9) a[i, j]++;
                            if (a[i, j + 1] == 9) a[i, j]++;

                            if (a[i + 1, j - 1] == 9) a[i, j]++;
                            if (a[i + 1, j] == 9) a[i, j]++;
                            if (a[i + 1, j + 1] == 9) a[i, j]++;
                        }
                    }
                }
            Print(a);

            Console.ReadKey();
        }

        static int[,] Input(byte ni, byte nj)
        {
            int[,] a = new int[ni, nj];

            string[] st;
            for (byte i = 0; i < ni; i++)
            {
                st = Console.ReadLine().Split();
                for (byte j = 0; j < nj; j++)
                    a[i, j] = Convert.ToInt32(st[j]);
            }
            Console.Write("\n");
            return a;
        }

        static void Print(int[,] a)
        {
            byte ni = (byte)a.GetLength(0);
            byte nj = (byte)a.GetLength(1);

            for (byte i = 0; i < ni; i++)
            {
                for (byte j = 0; j < nj; j++)
                    Console.Write($"{a[i, j]} ");
                Console.Write("\n");
            }

            Console.Write("\n");
        }

        static void Rndm(ref int[,] a, int p, int q)
        {
            byte ni = (byte)a.GetLength(0);
            byte nj = (byte)a.GetLength(1);
            Random rnd = new Random();

            for (byte i = 0; i < ni; i++)
                for (byte j = 0; j < nj; j++)
                    a[i, j] = rnd.Next(p, q + 1);
        }
    }
}
